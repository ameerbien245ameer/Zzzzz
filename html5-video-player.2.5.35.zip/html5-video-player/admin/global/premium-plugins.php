<?php
/*-------------------------------------------------------------------------------*/
// Developer page
/*-------------------------------------------------------------------------------*/
// add_action('admin_menu', 'bplugins_premium_plugins');

// function bplugins_premium_plugins()
// {
//     add_submenu_page('edit.php?post_type=videoplayer', 'Our Pro Plugins', 'Our Pro Plugins', 'manage_options', 'premium-plugins', 'bplugins_premium_plugins_callback');
// }

// function bplugins_premium_plugins_callback()
// {
//      $plugins = wp_remote_get('https://office-viewer.bplugins.com/premium-plugins-of-bplugins-llc/');
//       echo $plugins['body']; 
    
// }