// Code-mirror
jQuery(document).ready(function($) {
  wp.codeEditor.initialize($('#h5vp_style-custom_css'), cm_settings);
})